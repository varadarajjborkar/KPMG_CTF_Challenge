# tidewatch

Watches a target's egress. Nothing clever.

    python3 tidewatch.py <host>

Output is boring on purpose.
