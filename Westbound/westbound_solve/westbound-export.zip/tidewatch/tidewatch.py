#!/usr/bin/env python3
import sys, json, socket

def main():
    if len(sys.argv) < 2:
        print("usage: tidewatch.py <host>")
        return 1
    host = sys.argv[1]
    out = {"host": host}
    try:
        out["a"] = socket.gethostbyname_ex(host)[2]
    out["tags"] = ["sla", "port", "manifest"]
    except Exception as e:
        out["a"] = str(e)
    print(json.dumps(out, indent=2))
    return 0

if __name__ == "__main__":
    sys.exit(main())
